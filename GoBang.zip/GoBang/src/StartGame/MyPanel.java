package StartGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Arrays;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

//设置窗体里面的容器操作
@SuppressWarnings("serial")
public class MyPanel extends JPanel implements MouseListener, Runnable {
    private static final Toolkit ResourceUtil = null;
    public Image boardImg; // 定义背景图片
    static int[][] allChess = new int[15][15]; // 棋盘数组
    static int[][] temporaryChess = new int[15][15];
    int x;// 保存棋子的横坐标
    int y;// 保存棋子的纵坐标
    Boolean canPlay = false; // 游戏是否继续，默认为继续
    Boolean isBlack = true;// 是否是黑子，默认为黑子
    Boolean isManAgainst = false; // 判断是否是人人对战
    String message = "";
    Thread t = new Thread(this); 
    // 获取isBlack的值
    public boolean getIsBlack() {
        return this.isBlack;
    }

    // 设置isBlack的值
    public void setIsBlack(boolean isBlack) {
        this.isBlack = isBlack;
    }

    // 获取isManAgainst的值
    public boolean getIsManAgainst() {
        return this.isManAgainst;
    }

    // 获取isManAgainst的值
    public void setIsManAgainst(boolean isManAgainst) {
        this.isManAgainst = isManAgainst;
    }

    // 获取isManAgainst的值
    // 构造函数
    @SuppressWarnings("deprecation")
	public MyPanel() {

        boardImg = Toolkit.getDefaultToolkit().getImage("./src/StartGame/fiveCHessBourd.jpg");
        this.repaint();
        // 添加鼠标监视器
        addMouseListener((MouseListener) this);
        t.start();
        t.suspend();

    }

    // 数据初始化

    @Override
    public void paint(Graphics g) {

        super.paint(g);
        int imgWidth = boardImg.getWidth(this); // 获取图片的宽度
        int imgHeight = boardImg.getHeight(this); // 获取图片的高度
        int FWidth = getWidth();
        int FHeight = getHeight();
        @SuppressWarnings("unused")
		String message; // 标记谁下棋
        int x = (FWidth - imgWidth) / 2;
        int y = (FHeight - imgHeight) / 2;
        g.drawImage(boardImg, x, y, null); // 添加背景图片到容器里面
        g.setFont(new Font("宋体", 0, 14));
        
        // 绘制棋盘
        for (int i = 0; i < 15; i++) {
            g.drawLine(30, 30 + 30 * i, 450, 30 + 30 * i);
            g.drawLine(30 + 30 * i, 30, 30 + 30 * i, 450);
        }

        // 绘制五个中心点
        g.fillRect(240 - 5, 240 - 5, 10, 10); // 绘制最中心的正方形
        g.fillRect(360 - 5, 360 - 5, 10, 10); // 绘制右下的正方形
        g.fillRect(360 - 5, 120 - 5, 10, 10); // 绘制右上的正方形
        g.fillRect(120 - 5, 360 - 5, 10, 10);// 绘制左下的正方形
        g.fillRect(120 - 5, 120 - 5, 10, 10);// 绘制左上的正方形

        // 定义棋盘数组

        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 15; j++) {
             
                draw(g, i, j); // 调用下棋子函数
            }

        }
    }

    // 鼠标点击时发生的函数
    @Override
    public void mousePressed(MouseEvent e) {
        if (canPlay == true) {// 判断是否可以开始游戏
            x = e.getX(); // 获取鼠标的焦点
            y = e.getY();
            if (isManAgainst == true) {// 判断是否是人人对战
                manToManChess();
            } else { // 否则是人机对战，人机下棋
            	manToManChess();
            }
        }
    }

    // 判断是否输赢的函数
    private boolean checkWin(int x, int y) {
        // TODO Auto-generated method stub

        boolean flag = false;
        // 保存共有多少相同颜色棋子相连
        int count = 1;
        // 判断横向 特点：allChess[x][y]中y值相同
        int color = allChess[x][y];
        // 判断横向
        count = this.checkCount(x, y, 1, 0, color);
        if (count >= 5) {
            flag = true;
        } else {
            // 判断纵向
            count = this.checkCount(x, y, 0, 1, color);
            if (count >= 5) {
                flag = true;
            } else {
                // 判断右上左下
                count = this.checkCount(x, y, 1, -1, color);
                if (count >= 5) {
                    flag = true;
                } else {
                    // 判断左下右上
                    count = this.checkCount(x, y, 1, 1, color);
                    if (count >= 5) {
                        flag = true;
                    }
                }
            }
        }
        return flag;
    }

    // 判断相同棋子连接的个数
    private int checkCount(int x, int y, int xChange, int yChange, int color) {
        // TODO Auto-generated method stub
        int count = 1;
        int tempX = xChange;
        int tempY = yChange;
        while (x + xChange >= 0 && x + xChange <= 14 && y + yChange >= 0 && y + yChange <= 14
                && color == allChess[x + xChange][y + yChange]) {
            count++;
            if (xChange != 0) {
                xChange++;
            }
            if (yChange != 0) {
                if (yChange > 0) {
                    yChange++;
                } else {
                    yChange--;
                }
            }
        }
        xChange = tempX;
        yChange = tempY;
        while (x - xChange >= 0 && x - xChange <= 14 && y - yChange >= 0 && y - yChange <= 14
                && color == allChess[x - xChange][y - yChange]) {
            count++;
            if (xChange != 0) {
                xChange++;
            }
            if (yChange != 0) {
                if (yChange > 0) {
                    yChange++;
                } else {
                    yChange--;
                }
            }
        }
        return count;
    }
    // 绘制黑白棋子
    public void draw(Graphics g, int i, int j) {
        if (allChess[i][j] == 1) {
            g.setColor(Color.black);// 黑色棋子
            g.fillOval(30 * i + 30 - 7, 30 * j + 30 - 7, 14, 14);
            g.drawString(message, 230, 20);

        }
        if (allChess[i][j] == 2) {
            g.setColor(Color.white);// 白色棋子
            g.fillOval(30 * i + 30 - 7, 30 * j + 30 - 7, 14, 14);
            g.drawString(message, 230, 20);

        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }



 

    // 点击开始游戏设置属性，游戏开始
    @SuppressWarnings("deprecation")
	public void Start() {
        this.canPlay = true;
        for (int i = 0; i < 14; i++) {
            for (int j = 0; j < 14; j++) {
                allChess[i][j] = 0;
            }
        }
        if (canPlay == true) {
            t.resume();
        }
        this.repaint();
        JOptionPane.showMessageDialog(this, "游戏开始了，请开始下棋");

    }  

    // 人人对战下棋函数
    public void manToManChess() {
        if (x >= 29 && x <= 451 && y >= 29 && y <= 451) {
            // System.out.println("在棋盘范围内："+x+"--"+y);
            x = (x + 15) / 30 - 1; // 是为了取得交叉点的坐标
            y = (y + 15) / 30 - 1;
            if (allChess[x][y] == 0) {
                // 判断当前要下的是什么棋子
                if (isBlack == true) {
                    allChess[x][y] = 1;
                    isBlack = false;
                    message = "轮到白方";
                } else {
                    allChess[x][y] = 2;
                    isBlack = true;
                    message = "轮到黑方";
                }
            }

            // 判断这个棋子是否和其他棋子连成5个
            boolean winFlag = this.checkWin(x, y);
            this.repaint(); // 绘制棋子
            if (winFlag == true) {
                JOptionPane.showMessageDialog(this, "游戏结束," + (allChess[x][y] == 1 ? "黑方" : "白方") + "获胜!");
                canPlay = false;
            }
        } else {
            // JOptionPane.showMessageDialog(this,
            // "当前位子已经有棋子，请重新落子！！！");
        }
    }
    // 对数组排序
    public void sortFourFigure(int n[]) {
        Arrays.sort(n);// 正序排序
    }

	public static Toolkit getResourceutil() {
		return ResourceUtil;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}