package StartGame;

import javax.swing.JFrame;

public class StartEntrance {
    //public static boolean canPlay =false;
    public static void main(String[] args) {
        // 实例化一个窗口

        MyFrame myFrame = new MyFrame();
        myFrame.setVisible(true); // 设置窗口为可见
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 设置窗口关闭操作属性

    }

}